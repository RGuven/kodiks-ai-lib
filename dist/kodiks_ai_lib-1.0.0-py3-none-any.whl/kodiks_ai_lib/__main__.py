def main():
    print('Kodiks Ai Segmentation Service')


if __name__ == "__main__":
    main()
