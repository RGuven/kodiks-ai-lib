print('Working')


def func(a, b):
    print('func will work',a,b)
    return a + b